﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Vehicles_Gadaley.Models;

namespace Vehicles_Gadaley.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }


        public DbSet<Vehicle> Vehicles { get; set; }

        public DbSet<Car> Cars { get; set; }

        public DbSet<Bike> Bikes { get; set; }

        public DbSet<CarHistory> CarHistories { get; set; }

        public DbSet<BikeHistory> BikeHistories { get; set; }

        public DbSet<Owner> Owners { get; set; }

        public DbSet<Dealer> Dealers { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity<Owner>()
                .HasOne(c => c.IdentityUser)
                .WithOne()
                .HasForeignKey<Owner>(c => c.IdentityUserId);
        }
    }
}
