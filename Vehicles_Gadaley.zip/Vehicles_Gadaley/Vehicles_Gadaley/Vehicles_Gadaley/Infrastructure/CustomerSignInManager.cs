﻿using Vehicles_Gadaley.Data;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace Vehicles_Gadaley
{
    public class CustomerSignInManager<TUser> : SignInManager<TUser> where TUser : class
    {
        private readonly UserManager<TUser> _userManager;
        private readonly ApplicationDbContext _db;
        private readonly IHttpContextAccessor _contextAccessor;
        private readonly IAuthenticationSchemeProvider _schemeProvider;

        public CustomerSignInManager(UserManager<TUser> userManager, IHttpContextAccessor contextAccessor, IUserClaimsPrincipalFactory<TUser> claimsFactory, IOptions<IdentityOptions> optionsAccessor, ILogger<SignInManager<TUser>> logger, IAuthenticationSchemeProvider schemeProvider, ApplicationDbContext dbContext)
            : base(userManager, contextAccessor, claimsFactory, optionsAccessor, logger, schemeProvider)
        {
            _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
            _contextAccessor = contextAccessor ?? throw new ArgumentNullException(nameof(contextAccessor));
            _schemeProvider = schemeProvider ?? throw new ArgumentNullException(nameof(schemeProvider));
            _db = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        }

        public override async Task<SignInResult> PasswordSignInAsync(TUser user, string password, bool isPersistent, bool lockoutOnFailure)
        {
            var result = await base.PasswordSignInAsync(user, password, isPersistent, lockoutOnFailure);

            var appUser = user as IdentityUser;

            if (appUser != null) // user is logged in
            {
                await SetCustomerSessionVariable(appUser);
            }

            return result;
        }

        public override async Task SignInAsync(TUser user, bool isPersistent, string authenticationMethod = null)
        {
            await base.SignInAsync(user, isPersistent, authenticationMethod);

            var appUser = user as IdentityUser;

            if (appUser != null) // user is logged in
            {
                await SetCustomerSessionVariable(appUser);
            }
        }

        public override async Task SignOutAsync()
        {
            await base.SignOutAsync();

            var user = await _userManager.FindByNameAsync(_contextAccessor.HttpContext.User.Identity.Name) as IdentityUser;

            if (user != null)
            {
                // clear customer session variable
                _contextAccessor.HttpContext.Session.Remove(Constants.CustomerSessionKey);
            }
        }

        private async Task SetCustomerSessionVariable(IdentityUser user)
        {
            // get customer info
            var owner = await _db.Owners.FirstAsync(c => c.IdentityUserId == user.Id);

            // save customer to session
            _contextAccessor.HttpContext.Session.Set(Constants.CustomerSessionKey, owner);
        }
    }
}
