﻿using Vehicles_Gadaley.Data;
using Vehicles_Gadaley.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Vehicles_Gadaley
{
    public class CustomerUserManager<TUser> : UserManager<TUser> where TUser : class
    {
        private readonly ApplicationDbContext _context;

        public CustomerUserManager(IUserStore<TUser> store, IOptions<IdentityOptions> optionsAccessor, IPasswordHasher<TUser> passwordHasher, IEnumerable<IUserValidator<TUser>> userValidators, IEnumerable<IPasswordValidator<TUser>> passwordValidators, ILookupNormalizer keyNormalizer, IdentityErrorDescriber errors, IServiceProvider services, ILogger<UserManager<TUser>> logger, ApplicationDbContext context) :
            base(store, optionsAccessor, passwordHasher, userValidators, passwordValidators, keyNormalizer, errors, services, logger)
        {
            _context = context;
        }

        public override async Task<IdentityResult> CreateAsync(TUser user)
        {
            var result = await base.CreateAsync(user);

            await CreateCustomerForUser(user);

            return result;
        }

        private async Task CreateCustomerForUser(TUser user)
        {
            var appUser = user as IdentityUser;

            _context.Add(new Owner { IdentityUserId = appUser.Id });
            await _context.SaveChangesAsync();
        }
    }
}
