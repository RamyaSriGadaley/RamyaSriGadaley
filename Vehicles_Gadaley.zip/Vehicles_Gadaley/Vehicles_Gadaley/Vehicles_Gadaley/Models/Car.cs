﻿/*Ramya Sri Gadaley */
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Vehicles_Gadaley.Models
{
    public class Car : Vehicle //implementing Inheritance
    {
        [Required]
        [Display(Name = "Type of Car")]
        public String CarType { get; set; }

        [Required]
        public String Variant { get; set; }

        [Display(Name = "AirBags")]
        public int NumberOfAirBags { get; set; }

        public int Capacity { get; set; }

        //one to many relationship between Car and Dealer
        [Required]
        public int? DealerId { get; set; } //nullable
        public virtual Dealer Dealer { get; set; } //virtual - implementing Lazy loading
        
        //One to many relationship between CarHistory and Car
        public virtual ICollection<CarHistory> CarHistories { get; set; } //virtual - implementing Lazy loading

    }
}
