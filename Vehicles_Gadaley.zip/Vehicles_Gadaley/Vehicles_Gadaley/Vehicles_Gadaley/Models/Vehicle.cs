﻿/*Ramya Sri Gadaley */
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Vehicles_Gadaley.Models
{
    public class Vehicle
    {
        //properties/attributes
        //access control keyword - public/private
        public int ID { get; set; }

        //Validations for Inputs
        [Required]
        [MaxLength(20, ErrorMessage = "Must be less than 20 characters") ]
        [RegularExpression("^[a-zA-Z]+$",ErrorMessage = "Must be only alphabets")]
        public String Make { get; set; }
        public String Model { get; set; }
        public String Color { get; set; }

        [Display(Name = "Year")]
        
        
        public int YearManufactured { get; set; }

        [Display(Name = "New Vehicle")]
        public Boolean New { get; set; }
    }
}
