﻿/*Ramya Sri Gadaley */
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Vehicles_Gadaley.Models
{
    public class Owner
    {
        public int OwnerID { get; set; }

        //Validations for Inputs
        [Required]
        [Display(Name = "First Name")]
        [MaxLength(20, ErrorMessage = "First Name must be 20 characters or less")]
        [RegularExpression("^[a-zA-Z]+$", ErrorMessage = "First Name must be letters only")]
        public String FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        [MaxLength(20, ErrorMessage = "Last Name must be 20 characters or less")]
        [RegularExpression("^[a-zA-Z]+$", ErrorMessage = "Last Name must be letters only")]
        public String LastName { get; set; }

        [RegularExpression("^[0-9]+$", ErrorMessage = "Age must be in numbers only")]
        [Range(0,100, ErrorMessage = "Invalid Age")]
        public int Age { get; set; }

        public String City { get; set; }

        [Required]
        [Display(Name = "Phone Number")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        public String Phone { get; set; }

        public string IdentityUserId { get; set; }

        public virtual IdentityUser IdentityUser { get; set; }

        //One to many relationship between CarHistory and Owner
        public virtual ICollection<CarHistory> CarHistories { get; set; } //virtual - implementing Lazy loading


        //One to many relationship between BikeHistory and Owner
        public virtual ICollection<BikeHistory> BikeHistories { get; set; } //virtual - implementing Lazy loading

    }
}
