﻿/*Ramya Sri Gadaley */
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Vehicles_Gadaley.Models
{
    public class Bike : Vehicle //implementing Inheritance
    {
        [Required]
        [Display(Name = "Type of Bike")]
        public String BikeType { get; set; }

        public int Displacement { get; set; }

        //one to many relationship between Bike and Dealer
        public int? DealerId { get; set; } //nullable
        public virtual Dealer Dealer { get; set; } //virtual property - implementing Lazy loading

        //One to many relationship between BikeHistory and Bike
        public virtual ICollection<BikeHistory> BikeHistories { get; set; } //virtual - implementing Lazy loading
    }
}

