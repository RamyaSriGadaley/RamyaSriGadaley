﻿/*Ramya Sri Gadaley */
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Vehicles_Gadaley.Models
{
    public class CarHistory
    {
        
        public int CarHistoryID { get; set; }

        //one to many relationship between CarHistory and Car
        public int? CarId { get; set; } //nullable
        public virtual Car Car { get; set; } //virtual - implementing Lazy loading

        //one to many relationship between CarHistory and Owner
        public int? OwnerId { get; set; } //nullable
        public virtual Owner Owner { get; set; } //virtual - implementing Lazy loading

        [Display(Name = "Date of Purchase")]
        [DateValidation(ErrorMessage = "Sorry, the date can't be later than today's date")]
        public DateTime PurchasedDate { get; set; }

    }
}
