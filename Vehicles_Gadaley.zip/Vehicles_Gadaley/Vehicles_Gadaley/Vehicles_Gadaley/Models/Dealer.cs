﻿/*Ramya Sri Gadaley */
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Vehicles_Gadaley.Models
{
    public class Dealer
    {
        public int DealerID { get; set; }

        [Required]
        [Display(Name = "Dealer Name")]
        [MaxLength(15, ErrorMessage = "Dealer Name must be 50 characters or less")]
        [RegularExpression("^[a-zA-Z]+$", ErrorMessage = "Dealer Name must be letters only")]
        public String Name { get; set; }

        public String Address { get; set; }

        [Required]
        [Display(Name = "Phone Number")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        public String Phone { get; set; }

        [Display(Name = "Number of Vehicles Sold per Year")]
        public int VehiclesSoldPerYear { get; set; }


        //One to many relationship between Car and Dealers
        public virtual ICollection<Car> Cars { get; set; } //virtual - implementing Lazy loading

        //One to many relationship between Bike and Dealers
        public virtual ICollection<Bike> Bikes { get; set; } //virtual - implementing Lazy loading
    }
}
