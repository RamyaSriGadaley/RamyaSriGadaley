﻿/*Ramya Sri Gadaley */
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Vehicles_Gadaley.Models
{
    public class BikeHistory
    {
        
        public int BikeHistoryID { get; set; }

        //one to many relationship between BikeHistory and Bike  
        public int? BikeId { get; set; } //nullable
        public virtual Bike Bike { get; set; } //virtual - implementing Lazy loading

        //one to many relationship between BikeHistory and Owner
        public int? OwnerId { get; set; } //nullable
        public virtual Owner Owner { get; set; } //virtual - implementing Lazy loading

        [Required]
        [Display(Name = "Date of Purchase")]
        [DateValidation(ErrorMessage = "Sorry, the date can't be later than today's date")]
        public DateTime purchasedDate { get; set; }

        
    }
}
