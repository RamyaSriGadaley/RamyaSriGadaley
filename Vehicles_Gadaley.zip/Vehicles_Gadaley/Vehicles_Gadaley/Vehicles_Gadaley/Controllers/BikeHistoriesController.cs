﻿/*Ramya Sri Gadaley */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Vehicles_Gadaley.Data;
using Vehicles_Gadaley.Models;

namespace Vehicles_Gadaley.Controllers
{
    public class BikeHistoriesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BikeHistoriesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: BikeHistories
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.BikeHistories.Include(b => b.Bike).Include(b => b.Owner);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: BikeHistories/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bikeHistory = await _context.BikeHistories
                .Include(b => b.Bike)
                .Include(b => b.Owner)
                .FirstOrDefaultAsync(m => m.BikeHistoryID == id);
            if (bikeHistory == null)
            {
                return NotFound();
            }

            return View(bikeHistory);
        }

        // GET: BikeHistories/Create
        public IActionResult Create()
        {
            ViewData["BikeId"] = new SelectList(_context.Bikes, "ID", "BikeType");
            ViewData["OwnerId"] = new SelectList(_context.Owners, "OwnerID", "LastName");
            return View();
        }

        // POST: BikeHistories/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BikeHistoryID,BikeId,OwnerId,purchasedDate")] BikeHistory bikeHistory)
        {
            if (ModelState.IsValid)
            {
                _context.Add(bikeHistory);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            SetDropdownLists(bikeHistory);
            SetDropdownList(bikeHistory);
            return View(bikeHistory);
        }

        // GET: BikeHistories/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bikeHistory = await _context.BikeHistories.FindAsync(id);
            if (bikeHistory == null)
            {
                return NotFound();
            }


            SetDropdownLists(bikeHistory);
            SetDropdownList(bikeHistory);
            return View(bikeHistory);
        }

        // POST: BikeHistories/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BikeHistoryID,BikeId,OwnerId,purchasedDate")] BikeHistory bikeHistory)
        {
            if (id != bikeHistory.BikeHistoryID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(bikeHistory);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BikeHistoryExists(bikeHistory.BikeHistoryID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            //Applying Clean Coding
            SetDropdownLists(bikeHistory);
            SetDropdownList(bikeHistory);
            return View(bikeHistory);
        }

        // GET: BikeHistories/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bikeHistory = await _context.BikeHistories
                .Include(b => b.Bike)
                .Include(b => b.Owner)
                .FirstOrDefaultAsync(m => m.BikeHistoryID == id);
            if (bikeHistory == null)
            {
                return NotFound();
            }

            return View(bikeHistory);
        }

        // POST: BikeHistories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var bikeHistory = await _context.BikeHistories.FindAsync(id);
            _context.BikeHistories.Remove(bikeHistory);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BikeHistoryExists(int id)
        {
            return _context.BikeHistories.Any(e => e.BikeHistoryID == id);
        }

        //Implementing Clean Coding
        private void SetDropdownLists(BikeHistory bikeHistory)
        {
            ViewData["BikeId"] = new SelectList(_context.Bikes, "ID", "BikeType", bikeHistory.BikeId);

        }
        private void SetDropdownList(BikeHistory bikeHistory)
        {
            ViewData["OwnerId"] = new SelectList(_context.Owners, "OwnerID", "LastName", bikeHistory.OwnerId);
        }
    }
}
