﻿/*Ramya Sri Gadaley */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Vehicles_Gadaley.Data;
using Vehicles_Gadaley.Models;

namespace Vehicles_Gadaley.Controllers
{
    public class CarHistoriesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CarHistoriesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: CarHistories
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.CarHistories.Include(c => c.Car).Include(c => c.Owner);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: CarHistories/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carHistory = await _context.CarHistories
                .Include(c => c.Car)
                .Include(c => c.Owner)
                .FirstOrDefaultAsync(m => m.CarHistoryID == id);
            if (carHistory == null)
            {
                return NotFound();
            }

            return View(carHistory);
        }

        // GET: CarHistories/Create
        public IActionResult Create()
        {
            ViewData["CarId"] = new SelectList(_context.Cars, "ID","Make");
            ViewData["OwnerId"] = new SelectList(_context.Owners, "OwnerID", "LastName");
            return View();
        }

        // POST: CarHistories/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CarHistoryID,CarId,OwnerId,PurchasedDate")] CarHistory carHistory)
        {
            if (ModelState.IsValid)
            {
                _context.Add(carHistory);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            //Applying Clean Coding
            SetDropdownLists(carHistory);
            SetDropdownLists1(carHistory);
            return View(carHistory);
        }

        // GET: CarHistories/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carHistory = await _context.CarHistories.FindAsync(id);
            if (carHistory == null)
            {
                return NotFound();
            }
            SetDropdownLists(carHistory);
            SetDropdownLists1(carHistory);
            return View(carHistory);
        }

        // POST: CarHistories/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CarHistoryID,CarId,OwnerId,PurchasedDate")] CarHistory carHistory)
        {
            if (id != carHistory.CarHistoryID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(carHistory);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarHistoryExists(carHistory.CarHistoryID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            SetDropdownLists(carHistory);
            SetDropdownLists1(carHistory);
            return View(carHistory);
        }

        // GET: CarHistories/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carHistory = await _context.CarHistories
                .Include(c => c.Car)
                .Include(c => c.Owner)
                .FirstOrDefaultAsync(m => m.CarHistoryID == id);
            if (carHistory == null)
            {
                return NotFound();
            }

            return View(carHistory);
        }

        // POST: CarHistories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var carHistory = await _context.CarHistories.FindAsync(id);
            _context.CarHistories.Remove(carHistory);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CarHistoryExists(int id)
        {
            return _context.CarHistories.Any(e => e.CarHistoryID == id);
        }

        // Implementing clean coding
        private void SetDropdownLists(CarHistory carHistory)
        {

            ViewData["CarId"] = new SelectList(_context.Cars, "ID", "Make", carHistory.CarId);
        }

        private void SetDropdownLists1(CarHistory carHistory)
        {
          ViewData["OwnerId"] = new SelectList(_context.Owners, "OwnerID", "LastName", carHistory.OwnerId);
        }
    }
}
