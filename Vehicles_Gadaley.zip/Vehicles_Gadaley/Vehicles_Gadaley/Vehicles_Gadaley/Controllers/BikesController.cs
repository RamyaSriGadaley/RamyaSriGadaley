﻿/*Ramya Sri Gadaley */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Vehicles_Gadaley.Data;
using Vehicles_Gadaley.Models;

namespace Vehicles_Gadaley.Controllers
{
    public class BikesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BikesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Bikes
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Bikes.Include(b => b.Dealer);
            return View(await applicationDbContext.ToListAsync());
        }


        //Partial Post Method for the Details View
        //Needs to be type HttpPost
        [HttpPost]
        public IActionResult GetBikeHistories(int id)
        {
            var bikeHistories = _context.BikeHistories
                                        .Include(bh => bh.Owner)
                                        .Include(bh => bh.Bike)
                                        .Where(bh => bh.BikeId == id).ToList();

            return PartialView("_DetailsBikeHistories", bikeHistories);
        }


        // GET: Bikes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            var lastBike = HttpContext.Session.Get<Bike>("LastBikeViewed");

            if (id == null)
            {
                return NotFound();
            }

            var bike = await _context.Bikes
                .Include(b => b.Dealer)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (bike == null)
            {
                return NotFound();
            }

            //Implementing Session Tracking
            if (lastBike!= null && lastBike.ID == bike.ID)
            {
                ViewBag.Message = "You just clicked the same bike again!";
            }
            else
            {
                ViewBag.Message = "You just clicked on a new bike";
            }
            HttpContext.Session.Set<Bike>("LastBikeViewed", bike);

            return View(bike);
        }

        // GET: Bikes/Create
        public IActionResult Create()
        {
            SetDropdownLists();
            return View();
        }

        // POST: Bikes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BikeType,Displacement,DealerId,ID,Make,Model,Color,YearManufactured,New")] Bike bike)
        {
            if (ModelState.IsValid)
            {
                _context.Add(bike);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            SetDropdownLists(bike);
            return View(bike);
        }

        // GET: Bikes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bike = await _context.Bikes.FindAsync(id);
            if (bike == null)
            {
                return NotFound();
            }
            SetDropdownLists(bike);
            return View(bike);
        }

        // POST: Bikes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BikeType,Displacement,DealerId,ID,Make,Model,Color,YearManufactured,New")] Bike bike)
        {
            if (id != bike.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(bike);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BikeExists(bike.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            SetDropdownLists(bike);
            return View(bike);
        }

        // GET: Bikes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bike = await _context.Bikes
                .Include(b => b.Dealer)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (bike == null)
            {
                return NotFound();
            }

            return View(bike);
        }

        // POST: Bikes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var bike = await _context.Bikes.FindAsync(id);
            _context.Bikes.Remove(bike);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BikeExists(int id)
        {
            return _context.Bikes.Any(e => e.ID == id);
        }

        //Implementing Clean Coding
        private void SetDropdownLists()
        {
            ViewData["DealerId"] = new SelectList(_context.Dealers, "DealerID", "Name");
        }

        private void SetDropdownLists(Bike bike)
        {
            ViewData["DealerId"] = new SelectList(_context.Dealers, "DealerID", "Name", bike.DealerId);
        }
    }
}
