﻿//Ramya Sri Gadaley
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vehicles_Gadaley
{
    public static class Constants
    {
        public const string AdministratorRole = "Administrator";
        public const string StandardUserRole = "StandardUser";
        public const string CustomerSessionKey = "Owner";

        
    }

}

