﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Vehicles_Gadaley.Models;

namespace Vehicles_Gadaley.ViewModels
{
    public class OwnerSearchViewModel
    {   
        //implementing view model to perform search operation
        public Owner Owner { get; set; }
        public string SearchError { get; set; }
        public List<Owner> ResultList { get; set; }
        public OwnerSearchViewModel()
        {
            ResultList = new List<Owner>();
        }
    }
}
